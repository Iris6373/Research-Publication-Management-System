<?php
$link = mysqli_connect("localhost","root","","se project");
if(!$link)
{
  echo "Couldn't connect Database Please check the Connection.";
}
$IDtoChange = $_GET['ID'];
$StatusDecided = $_GET['ApprovalStatus'];
if($StatusDecided == 0)  //Rejection
{
  $q = "Disapproved";
  mysqli_query($link,"UPDATE journals SET ApprovalStatus='$q' WHERE ID = '$IDtoChange'");
  //Mail
  //the subject
  $sub = "Sorry, Your File Has Been Disapproved";
  //the message
  $msg = "The Journal You have sent to Journal Hub was Disapproved by the Editor";
  //recipient email here
  $queryToGetUsername =mysqli_query($link,"select * from journals where ID='$IDtoChange'");
  $UR = mysqli_fetch_array($queryToGetUsername);
  $UsernameOfRejected = $UR['Username'];
  $EmailGet = mysqli_query($link,"select * from login where Username = '$UsernameOfRejected'");
  $Eg = mysqli_fetch_array($EmailGet);
  $rec = $Eg['Email'];
  //send email
  mail($rec,$sub,$msg);

  header("Location: ../SE/AdminFirstPage.php");
  exit();
}
else   //Approved
{
  $qt = "Approved";
  mysqli_query($link,"UPDATE journals SET ApprovalStatus='$qt' WHERE ID = '$IDtoChange'");
  header("Location: ../SE/AdminFirstPage.php");
  exit();
}

 ?>
