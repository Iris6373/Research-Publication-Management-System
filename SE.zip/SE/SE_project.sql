-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 27, 2020 at 03:00 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iwp project`
--

-- --------------------------------------------------------

--
-- Table structure for table `info`
--

CREATE TABLE `info` (
  `ID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `Title` text NOT NULL,
  `Classifications` text NOT NULL,
  `Type` text NOT NULL,
  `Coauthors` text NOT NULL,
  `Comments` text NOT NULL,
  `Abstract` text NOT NULL,
  `Keywords` text NOT NULL,
  `Funds` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `info`
--

INSERT INTO `info` (`ID`, `Username`, `Title`, `Classifications`, `Type`, `Coauthors`, `Comments`, `Abstract`, `Keywords`, `Funds`) VALUES
(145, 'Author', 'Journal Hub IWP ', 'Web programming;Data Structures;Algorithms;Logical Circuit;', 'Review Article', 'Kaarthik;Dhanish', '\r\nThank you very much for this opportunity, sir.', 'Web development is the work involved in developing a Web site for the Internet (World Wide Web) or an intranet (a private network).[1] Web development can range from developing a simple single static page of plain text to complex Web-based Internet applications (Web apps), electronic businesses, and social network services. A more comprehensive list of tasks to which Web development commonly refers, may include Web engineering, Web design, Web content development, client liaison, client-side/server-side scripting, Web server and network security configuration, and e-commerce development.\r\n\r\nAmong Web professionals, \"Web development\" usually refers to the main non-design aspects of building Web sites: writing markup and coding.[2] Web development may use content management systems (CMS) to make content changes easier and available with basic technical skills.\r\n\r\n', 'HTML;CSS;JAVASCRIPT;PHP;MYSQL', '1 lakh');

-- --------------------------------------------------------

--
-- Table structure for table `journals`
--

CREATE TABLE `journals` (
  `ID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `ApprovalStatus` text NOT NULL,
  `RApproval` text NOT NULL,
  `FileName` text NOT NULL,
  `ReviewerAssigned` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `journals`
--

INSERT INTO `journals` (`ID`, `Username`, `ApprovalStatus`, `RApproval`, `FileName`, `ReviewerAssigned`) VALUES
(52, 'Author', 'Approved', 'Approved', '145_145_doc2.pdf', 'Set');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int(11) NOT NULL,
  `Username` text NOT NULL,
  `Email` text NOT NULL,
  `Password` text NOT NULL,
  `UserStatus` text NOT NULL,
  `FirstName` text NOT NULL,
  `LastName` text NOT NULL,
  `Country` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `Username`, `Email`, `Password`, `UserStatus`, `FirstName`, `LastName`, `Country`) VALUES
(2, 'Editor', 'journalhubteam1@gmail.com', 'a1', 'Admin', '', '', ''),
(3, 'Reviewer1', 'Reviewer1@gmail.com', 'a1', 'Reviewer', '', '', ''),
(4, 'Reviewer2', 'Reviewer2@gmail.com', 'a2', 'Reviewer', '', '', ''),
(6, 'Author', 'authorrriwp@gmail.com', 'a1', 'User', 'Girish', 'Sudhakar', 'India');

-- --------------------------------------------------------

--
-- Table structure for table `reviewerstable`
--

CREATE TABLE `reviewerstable` (
  `ID` int(11) NOT NULL,
  `JournalID` int(11) NOT NULL,
  `FileName` text NOT NULL,
  `ReviewersSugg` text NOT NULL,
  `RApproval` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviewerstable`
--

INSERT INTO `reviewerstable` (`ID`, `JournalID`, `FileName`, `ReviewersSugg`, `RApproval`) VALUES
(19, 52, '145_145_doc2.pdf', 'Reviewer1', 'Approved');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `journals`
--
ALTER TABLE `journals`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `reviewerstable`
--
ALTER TABLE `reviewerstable`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `info`
--
ALTER TABLE `info`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;

--
-- AUTO_INCREMENT for table `journals`
--
ALTER TABLE `journals`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reviewerstable`
--
ALTER TABLE `reviewerstable`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
