<html>
    <head>
        <title>Author_Main_Menu</title>
        <link rel = "stylesheet" type = "text/css" href = "Author_Main_Menu.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>

      <div class = "z">
          <div class="nav-bar">
          <img src="j.jpg" alt="JournalHub" class="Logo">
            <div class="Links">
              <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
              session_start();
              echo $_SESSION['Username'];
               ?> </a>&nbsp;
              <a href="Author_Main_Menu.php">MAIN MENU</a>
              <a href="Update_my_Info.php">UPDATE MY INFORMATION</a>
              <a href="1.php">SUBMIT A MANUSCRIPT</a>
              <a href="Logout.php">LOGOUT</a>
            </div>
          <hr color="orange">
      </div>

      <div class="vl"></div>

      <div class = "p">
          <h2><span style = "font-family: Comic Sans MS, cursive, sans-serif">Author Main Menu</span></h2>
      </div>

      <?php
      $link = mysqli_connect("localhost","root","","se project");
      if(!$link)
      {
        echo "Couldn't connect Database Please check the Connection.";
      }
      $query1 = mysqli_query($link,'select * from journals where ApprovalStatus = "Pending" and RApproval = "Pending"');
      $query2 = mysqli_query($link,'select * from journals where ApprovalStatus = "Approved" and RApproval = "Pending"');
      $query3 = mysqli_query($link,'select * from journals where ApprovalStatus = "Approved" and RApproval = "Approved"');
      $query4 = mysqli_query($link,"select * from journals where ApprovalStatus = 'Disapproved' or RApproval = 'Disapproved'");
      $result1 = mysqli_fetch_array($query1);
      $result2 = mysqli_fetch_array($query2);
      $result3 = mysqli_fetch_array($query3);
      $result4 = mysqli_fetch_array($query4);
      ?>

      <fieldset class = "k">
          <legend style = "border-radius: 12px; border-style: groove; background-color: white; font-size:12px; padding: 5px"><b><span class = "l" style = "color: darkorange">New Submissions</span></b></legend>
          <pre><p style = "font-size:14px">                  <a href = "1.php" style = "text-decoration: none;"><span class = "l">Submit New Manuscript</span></a></p></pre>
          <p style = "font-size:14px; margin-left: 138px"><span class = "l">Submissions Waiting for Editor's Approval (<?php if(isset($result1)) echo mysqli_num_rows($query1); ?>)</span></p>
          <p style = "font-size:14px; margin-left: 138px"><span class = "l">Submissions Being Processed (<?php if(isset($result2)) echo mysqli_num_rows($query2); ?>)</span></p>
      </div>

      <fieldset class = "n">
              <legend style = "display: block; border-radius: 12px; border-style: groove; background-color: white; font-size:12px; padding: 5px"><b><span class = "l" style = "color: forestgreen">Completed</span></b></legend>
          <pre><p style = "font-size:14px">                  <span class = "l">Approved Submissions (<?php if(isset($result3)) { echo mysqli_num_rows($query3); } ?>)</span></p></pre>
          <pre><p style = "font-size:14px">                  <span class = "l">Disapproved Submissions (<?php if(isset($result4)) echo mysqli_num_rows($query4); ?>)</span></p></pre>
      </div>
    </body>
</html>
