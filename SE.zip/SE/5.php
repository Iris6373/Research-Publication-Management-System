<!DOCTYPE html>
<html>
  <head>
    <title>5</title>
    <link rel="1" href="1.PNG">
    <link rel="stylesheet" href="5.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script>
        function prev()
        {
            document.location.href = "add.php";
        }
    </script>
  </head>
  <body>
    <div class = "p">
        <h5><i>Please provide the requested <br>information.</i></h5>
    </div>
    <div class="nav-bar">
      <img src="j.jpg" alt="JournalHub" class="Logo">
        <div class="Links">
          <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
              session_start();
              echo $_SESSION['Username'];
               ?> </a>&nbsp;
        </div>
      <hr color="orange">
    </div>
    <form action = "" method = "POST">
    <div class="center">
      <div class="inside-center">
        <p>Comments</p>
      </div>
      <div class="sub-content">
        <br>
        <hr color="orange">
        <pre><p><span style = "font-family: Times New Roman">Please enter any additional comments you would like to send to the publication office. These comments will not appear directly in your
submission.</span></p></pre>
        <hr color="orange"><br>
        <textarea rows = 4 cols = 119 name = "t" required></textarea>
      </div>
    </div>
    <button type="submit" class = "button" name = "s"><span>Proceed </span></button>
    <button class="b" onclick = "prev()"><span>Back </span></button>
  </form>
  </body>

  <?php
    $id = $_SESSION['IDab'];
    if(isset($_POST['s']))
    {
        $co = $_POST['t'];
        $link = mysqli_connect("localhost","root","","se project");
        if(!$link)
        {
            echo "Couldn't connect Database Please check the Connection.";
        }
        mysqli_query($link, "update info set Comments = '$co' where ID = '$id'");
        echo "<script>window.location.href='6.php';</script>";
    }
  ?>

</html>
