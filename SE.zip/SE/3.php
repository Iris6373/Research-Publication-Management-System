<!DOCTYPE html>
<html>
    <head>
        <title>3</title>
        <link rel="1" href="1.PNG">
        <link rel="stylesheet" href="3.css">
        <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>
    <body>
      <div class = "p">
          <h5 style = "font-family: Comic Sans MS, cursive, sans-serif"><i>Please provide the requested <br>information.</i></h5>
      </div>
      <div class="nav-bar">
        <img src="j.jpg" alt="JournalHub" class="Logo">
          <div class="Links">
            <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php session_start(); echo $_SESSION['Username']; ?> </a>&nbsp;
          </div>
        <hr color="orange">
      </div>
      <div class="center">
        <div class="inside-center">
          <p>Suggest Reviewers</p>
        </div>
        <div class="sub-content">
          <br>
          <hr color="orange">
          <pre><p><span style = "font-family: Comic Sans MS, cursive, sans-serif; font-size: 12px">  Please suggest potential reviewers for this submission and provide specific reasons for your suggestion in the comments box for each
  person. Please note that the editorial office may not use your suggestions, but your help is appreciated and may speed up the selection
  of appropriate reviewers.</span></p></pre>
          <hr color="orange">
          <div class = "hi">
              <p><span style = "font-family: Comic Sans MS, cursive, sans-serif">Current Suggested Reviewers List</span></p>
              <p id = "fir"></p><br>
          </div>
          <button id="myBtn" style = "position: absolute; top: 130%; font-size: 14px; padding: 8px; background-color: blue; color: white; cursor: pointer"><i class="fa fa-plus"></i> Add Suggested Reviewer</button>
        </div>


        <!-- The Modal -->
        <div id="myModal" class="modal">

          <!-- Modal content -->
          <div class="modal-content">
            <div class="modal-header">
              <span class="close">&times;</span>
              <h2>Enter Suggested Reviewer Details</h2>
            </div>
            <div class="modal-body">
                <pre><p><span style = "color: red; font-family: Comic Sans MS, cursive, sans-serif">                   Given/First Name *</span>        <input type="text" id = "first" size = "26" required><br><span style = "font-family: Comic Sans MS, cursive, sans-serif">                   Middle Name *                   <input type="text" id = "middle" size = "26"><br><span style = "color: red; font-family: Comic Sans MS, cursive, sans-serif">                   Re-type Password *            <input type="password"  size = "26" required></span><br><span style = "font-family: Comic Sans MS, cursive, sans-serif">                   Degree                               <input type="text"  size = "26"><br><span style = "font-family: Comic Sans MS, cursive, sans-serif">                   Position                              <input type="text"  size = "26"><br><span style = "font-family: Comic Sans MS, cursive, sans-serif">                   Institution                         <input type="text"  size = "26"><br><span style = "color: red; font-family: Comic Sans MS, cursive, sans-serif">                   Department *                     <input type="text"  size = "26"></span><br><span style = "font-family: Comic Sans MS, cursive, sans-serif">                   E-mail                                 <input type="text"  size = "26"><br>                   <span style = "position:absolute; top: 65%; left: 14.2%; font-family: Comic Sans MS, cursive, sans-serif">Reason</span>                                          <textarea type = "text" rows="4" cols="26"></textarea></p></pre>
            </div>
            <div class="modal-footer">
              <br><center><span><input type= "submit" id = "sub"><span class = "a"></span>
              </center><br>
            </div>
          </div>

        </div>


      </div>

      <button class="button" onclick = "next()"><span>Proceed </span></button>
      <button class="b"><span>Back </span></button>

    </body>

    <script>
    // Get the modal
    var modal = document.getElementById("myModal");

    // Get the button that opens the modal
    var btn = document.getElementById("myBtn");

    // Get the button that submits the modal
    var bt = document.getElementById("sub");

    var f = document.getElementById("first");
    alert(f);
    // Get the <span> element that closes the modal
    var span = document.getElementsByClassName("close")[0];

    // When the user clicks the button, open the modal
    btn.onclick = function() {
      modal.style.display = "block";
    }

    // When the user clicks on <span> (x), close the modal
    span.onclick = function() {
      modal.style.display = "none";
    }

    bt.onclick = function() {
      document.getElementById('fir').innerHTML = f;
      modal.style.display = "none";
    }

    // When the user clicks anywhere outside of the modal, close it
    window.onclick = function(event) {
      if (event.target == modal) {
        modal.style.display = "none";
      }
    }
    </script>

</html>
