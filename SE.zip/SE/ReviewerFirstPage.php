<!DOCTYPE html>
<html>
  <head>
    <title>JournalHub</title>
    <link rel="stylesheet" href="ReviewerFirstPage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <div class="nav-bar">
      <img src="Logo.PNG" alt="JournalHub" class="Logo">
      <div class="links">
        <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
        session_start();
        echo $_SESSION['Username'];
         ?> </a>
        <a href="Logout.php">Logout</a>
      </div>
    </div>
    <hr color="orange">
    <div class="List">
      <h2>Files yet to be Evaluated: </h2>
      <table>
        <thead>
          <th>Journal ID</th>
          <th>File</th>
          <th>Approve</th>
          <th>Disapprove</th>
        </thead>
        <?php
        $link = mysqli_connect("localhost","root","","se project");
        if(!$link)
        {
          echo "Couldn't connect Database Please check the Connection.";
        }
        $RName = $_SESSION['Username'];
        $query = mysqli_query($link,"select * from reviewerstable where ReviewersSugg='$RName' and RApproval = 'Pending'");
        while($result = mysqli_fetch_array($query))
        {
          echo "<tr>";
          echo "<td>".$result['JournalID']."</td>";
          $fi = $result['FileName'];
          $fileNameOrg  = explode('.', $fi);
          echo "<td><a href = './JournalFiles/".$fi."' download>".$fi."</a></td>";
          $temp = $result['JournalID'];
          $s = 1;
          $n = 0;
          echo '<td><a href="ReviewerResult.php?ID='.urlencode($temp).'&ApprovalStatus='.urlencode($s).'">Approve</a></td>';
          echo '<td><a href="ReviewerResult.php?ID='.urlencode($temp).'&ApprovalStatus='.urlencode($n).'">Disapprove</a></td>';
          echo "</tr>";
        }
         ?>
      </table>
    </div>
  </body>
</html>
