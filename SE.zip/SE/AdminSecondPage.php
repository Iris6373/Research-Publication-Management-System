<!DOCTYPE html>
<html>
  <head>
    <title>Journal Hub</title>
    <link rel="icon" href="Icon.PNG">
    <link rel="stylesheet" href="AdminSecondPage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <div class="nav-bar">
      <img src="Logo.PNG" alt="JournalHub" class="Logo">
      <div class="links">
      <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
      session_start();
      echo $_SESSION['Username'];
       ?> </a>
      <a href="Logout.php">Logout</a>
      </div>
    </div>
    <hr color="orange">
    <div class="List">
      <table>
        <thead>
          <th>Username</th>
          <th>File</th>
          <th>Approve</th>
          <th>Disapprove</th>
        </thead>
        <?php
        $link = mysqli_connect("localhost","root","","se project");
        if(!$link)
        {
          echo "Couldn't connect Database Please check the Connection.";
        }
        $query = mysqli_query($link,"select * from journals where ApprovalStatus='Pending'");
        if(mysqli_num_rows($query)>0)
        {
          while($result = mysqli_fetch_array($query))
          {
            echo "<tr>";
            echo "<td>".$result['Username']."</td>";
            $fi = $result['FileName'];
            $fileNameOrg  = explode('.', $fi);
            echo "<td><a href = './JournalFiles/".$fi."' download>".$fi."</a></td>";
            $temp = $result['ID'];
            $s = 1;
            $n = 0;
            echo '<td><a href="AdminResult.php?ID='.urlencode($temp).'&ApprovalStatus='.urlencode($s).'">Approve</a></td>';
            echo '<td><a href="AdminResult.php?ID='.urlencode($temp).'&ApprovalStatus='.urlencode($n).'">Disapprove</a></td>';
            echo '</tr>';
          }
        }
        ?>

      </table>
    </div>

  </body>
<html>
