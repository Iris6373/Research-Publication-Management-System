<!DOCTYPE html>
<html>
  <head>
    <title>Journal Hub</title>
    <link rel="icon" href="Icon.PNG">
    <link rel="stylesheet" href="AdminFirstPage.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  </head>
  <body>
    <div class="nav-bar">
      <img src="Logo.PNG" alt="JournalHub" class="Logo">
      <div class="links">
      <a id="special"> <i class="fa fa-user-circle-o"> </i> <?php
      session_start();
      echo $_SESSION['Username'];
       ?> </a>
      <a href="Logout.php">Logout</a>
      </div>
    </div>
    <hr color="orange">
    <?php
    $link = mysqli_connect("localhost","root","","se project");
    if(!$link)
    {
      echo "Couldn't connect Database Please check the Connection.";
    }
    $queryPending = mysqli_query($link,"select * from journals where ApprovalStatus = 'Pending' ");
    $resultPending = mysqli_fetch_array($queryPending);

    $queryApproved = mysqli_query($link,"select * from journals where ApprovalStatus = 'Approved'");
    $resultApproved = mysqli_fetch_array($queryApproved);

    $queryDisapproved = mysqli_query($link,"select * from journals where ApprovalStatus = 'Disapproved'");
    $resultDisapproved = mysqli_fetch_array($queryDisapproved);

    $RqueryPending = mysqli_query($link,"select * from journals where ReviewerAssigned = 'Pending' and ApprovalStatus='Approved'");
    $RresultPending = mysqli_fetch_array($RqueryPending);
    ?>
    <div class="Work">
      <fieldset>
        <legend>Works</legend>
        <p><a href="AdminSecondPage.php">Files to be Checked (<?php if(isset($resultPending)){echo mysqli_num_rows($queryPending);}?>)</a></p>
        <p>Files Approved (<?php if(isset($resultApproved)){echo mysqli_num_rows($queryApproved);}?>)</p>
        <p>Files Disapproved (<?php if(isset($resultDisapproved)){echo mysqli_num_rows($queryDisapproved);}?>)</p>
        <p> <a href="AdminThirdPage.php">Reviewers To be Assigned(<?php if(isset($RresultPending)){echo mysqli_num_rows($RqueryPending);}?>)</a></p>
      </fieldset>
    </div>
  </body>
</html>
